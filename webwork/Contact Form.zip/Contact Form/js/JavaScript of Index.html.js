//Function of public key

(function(){
    emailjs.init("NCQus3oXVKbPWprx0");
 })(); 

 //Function of sendMail(params)

 function sendMail(params) 
{
    
    var uName = document.getElementById("name").value;
    // var uEmail = document.getElementById("email").value;
	var uSubject = document.getElementById("subject").value;
	var uBody = document.getElementById("message").value;

	var errorABC = document.getElementById('form-message-warning');
	var success = document.getElementById('form-message-success');


	var tempParam = {
		from_name : uName,
		to_name : "Azaz ul Haq",
		subject : uSubject,
		message : uBody
		};

		emailjs.send('service_htjaol6' , 'template_xqb9w7k' , tempParam)
		.then(function (response){
		//success
		errorABC.style.display = "none";
		success.style.display = "inline-block";
		}, function (error){
		//error
		success.style.display = "none";
		errorABC.innerHTML = "Error: " + error.status;
		errorABC.style.display = "inline-block";			
			
		});
}

